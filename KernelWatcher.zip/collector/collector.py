from __future__ import annotations

import argparse
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
from pathlib import Path
import struct
import sys
import time
from typing import Any, Iterable


DEVICE_PATH = r"\\.\KernelWatcher"
GENERIC_READ = 0x80000000
FILE_SHARE_READ = 0x00000001
FILE_SHARE_WRITE = 0x00000002
OPEN_EXISTING = 3
FILE_ATTRIBUTE_NORMAL = 0x80
INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value
ERROR_NO_MORE_ITEMS = 259
MAX_PATH_CHARS = 260
EVENT_STRUCT = struct.Struct("<IIQB7x520s")
HEADER_STRUCT = struct.Struct("<II")


def ctl_code(device_type: int, function: int, method: int, access: int) -> int:
    return (device_type << 16) | (access << 14) | (function << 2) | method


IOCTL_KW_GET_EVENTS = ctl_code(0x8000, 0x800, 0, 1)


def api_error(api: str) -> OSError:
    code = ctypes.get_last_error()
    return OSError(f"{api}: {ctypes.WinError(code)}")


def load_config(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        config = json.load(f)
    for key in ("driver_name_patterns", "driver_sha256", "process_name_patterns"):
        config.setdefault(key, [])
        config[key] = [str(value).lower() for value in config[key]]
    config.setdefault("scores", {})
    return config


def sha256_file(path: Path) -> str | None:
    try:
        digest = hashlib.sha256()
        with path.open("rb") as f:
            for block in iter(lambda: f.read(1024 * 1024), b""):
                digest.update(block)
        return digest.hexdigest()
    except OSError:
        return None


def normalize_driver_path(raw_path: str) -> Path | None:
    if not raw_path:
        return None
    windows = os.environ.get("SystemRoot", r"C:\Windows")
    value = raw_path.replace("/", "\\")
    lower = value.lower()
    if lower.startswith("\\systemroot\\"):
        value = windows + value[len(r"\SystemRoot") :]
    elif lower.startswith("system32\\"):
        value = str(Path(windows) / value)
    elif lower.startswith("\\??\\"):
        value = value[4:]
    return Path(value)


def enable_debug_privilege() -> None:
    if os.name != "nt":
        return

    class LUID(ctypes.Structure):
        _fields_ = [("LowPart", wintypes.DWORD), ("HighPart", wintypes.LONG)]

    class LUID_AND_ATTRIBUTES(ctypes.Structure):
        _fields_ = [("Luid", LUID), ("Attributes", wintypes.DWORD)]

    class TOKEN_PRIVILEGES(ctypes.Structure):
        _fields_ = [("PrivilegeCount", wintypes.DWORD),
                    ("Privileges", LUID_AND_ATTRIBUTES * 1)]

    TOKEN_ADJUST_PRIVILEGES = 0x20
    TOKEN_QUERY = 0x8
    SE_PRIVILEGE_ENABLED = 0x2
    ERROR_NOT_ALL_ASSIGNED = 1300
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel32.GetCurrentProcess.argtypes = []
    kernel32.GetCurrentProcess.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    advapi32.OpenProcessToken.argtypes = [
        wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE)]
    advapi32.OpenProcessToken.restype = wintypes.BOOL
    advapi32.LookupPrivilegeValueW.argtypes = [
        wintypes.LPCWSTR, wintypes.LPCWSTR, ctypes.POINTER(LUID)]
    advapi32.LookupPrivilegeValueW.restype = wintypes.BOOL
    advapi32.AdjustTokenPrivileges.argtypes = [
        wintypes.HANDLE, wintypes.BOOL, ctypes.POINTER(TOKEN_PRIVILEGES),
        wintypes.DWORD, ctypes.POINTER(TOKEN_PRIVILEGES),
        ctypes.POINTER(wintypes.DWORD)]
    advapi32.AdjustTokenPrivileges.restype = wintypes.BOOL
    token = wintypes.HANDLE()
    try:
        if not advapi32.OpenProcessToken(
            kernel32.GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,
            ctypes.byref(token)
        ):
            raise api_error("OpenProcessToken")
        luid = LUID()
        if not advapi32.LookupPrivilegeValueW(
            None, "SeDebugPrivilege", ctypes.byref(luid)
        ):
            raise api_error("LookupPrivilegeValueW")
        state = TOKEN_PRIVILEGES(1, (LUID_AND_ATTRIBUTES(luid, SE_PRIVILEGE_ENABLED),))
        ctypes.set_last_error(0)
        if not advapi32.AdjustTokenPrivileges(
            token, False, ctypes.byref(state), 0, None, None
        ):
            raise api_error("AdjustTokenPrivileges")
        error = ctypes.get_last_error()
        if error == ERROR_NOT_ALL_ASSIGNED:
            raise PermissionError("SeDebugPrivilege is not assigned to this process")
    finally:
        if token:
            kernel32.CloseHandle(token)


def enumerate_drivers() -> list[dict[str, Any]]:
    if os.name != "nt":
        return []
    enable_debug_privilege()
    psapi = ctypes.WinDLL("psapi", use_last_error=True)
    enum_drivers = psapi.EnumDeviceDrivers
    enum_drivers.argtypes = [ctypes.POINTER(ctypes.c_void_p), wintypes.DWORD,
                             ctypes.POINTER(wintypes.DWORD)]
    enum_drivers.restype = wintypes.BOOL
    get_path = psapi.GetDeviceDriverFileNameW
    get_path.argtypes = [ctypes.c_void_p, wintypes.LPWSTR, wintypes.DWORD]
    get_path.restype = wintypes.DWORD

    needed = wintypes.DWORD()
    addresses = (ctypes.c_void_p * 2048)()
    if not enum_drivers(addresses, ctypes.sizeof(addresses), ctypes.byref(needed)):
        raise ctypes.WinError(ctypes.get_last_error())
    count = min(needed.value // ctypes.sizeof(ctypes.c_void_p), len(addresses))
    if count and not any(addresses[i] for i in range(count)):
        raise PermissionError(
            "EnumDeviceDrivers returned NULL addresses. Run as administrator "
            "with SeDebugPrivilege enabled on Windows 11 24H2 or later."
        )

    result: list[dict[str, Any]] = []
    for i in range(count):
        buffer = ctypes.create_unicode_buffer(32768)
        if not get_path(addresses[i], buffer, len(buffer)):
            continue
        normalized = normalize_driver_path(buffer.value)
        result.append({
            "base": int(addresses[i] or 0),
            "raw_path": buffer.value,
            "path": str(normalized) if normalized else "",
            "name": normalized.name if normalized else Path(buffer.value).name,
        })
    return result


class KernelWatcherDevice:
    def __init__(self) -> None:
        if os.name != "nt":
            raise OSError("KernelWatcher device access requires Windows")
        self.kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        self.kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        self.kernel32.CloseHandle.restype = wintypes.BOOL
        self.kernel32.CreateFileW.argtypes = [
            wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p,
            wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE,
        ]
        self.kernel32.CreateFileW.restype = wintypes.HANDLE
        self.kernel32.DeviceIoControl.argtypes = [
            wintypes.HANDLE, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD,
            ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD),
            ctypes.c_void_p,
        ]
        self.kernel32.DeviceIoControl.restype = wintypes.BOOL
        self.handle = self.kernel32.CreateFileW(
            DEVICE_PATH, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
            None, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, None,
        )
        if self.handle == INVALID_HANDLE_VALUE:
            raise api_error("CreateFileW(KernelWatcher)")

    def close(self) -> None:
        if self.handle not in (None, INVALID_HANDLE_VALUE):
            self.kernel32.CloseHandle(self.handle)
            self.handle = None

    def read_events(self, capacity: int = 128) -> tuple[int, list[dict[str, Any]]]:
        output = ctypes.create_string_buffer(HEADER_STRUCT.size + EVENT_STRUCT.size * capacity)
        returned = wintypes.DWORD()
        ok = self.kernel32.DeviceIoControl(
            self.handle, IOCTL_KW_GET_EVENTS, None, 0,
            output, len(output), ctypes.byref(returned), None,
        )
        if not ok:
            raise api_error("DeviceIoControl(GET_EVENTS)")
        if returned.value < HEADER_STRUCT.size:
            raise ValueError("DeviceIoControl returned a truncated batch header")
        count, dropped = HEADER_STRUCT.unpack_from(output.raw)
        if count > capacity or HEADER_STRUCT.size + count * EVENT_STRUCT.size > returned.value:
            raise ValueError("DeviceIoControl returned an invalid event count/size")
        events = []
        for index in range(min(count, capacity)):
            offset = HEADER_STRUCT.size + index * EVENT_STRUCT.size
            pid, ppid, timestamp_100ns, created, raw_name = EVENT_STRUCT.unpack_from(
                output.raw, offset
            )
            image = raw_name.decode("utf-16-le", errors="ignore").split("\0", 1)[0]
            events.append({
                "pid": pid,
                "parent_pid": ppid,
                "timestamp_100ns": timestamp_100ns,
                "created": bool(created),
                "image_path": image,
            })
        return dropped, events

    def __enter__(self) -> "KernelWatcherDevice":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


class JsonlWriter:
    def __init__(self, path: Path, session_id: str, player_id: str) -> None:
        self.path = path
        self.session_id = session_id
        self.player_id = player_id
        self.started = time.monotonic()
        path.parent.mkdir(parents=True, exist_ok=True)

    def emit(self, evidence: dict[str, Any], reasons: list[str], score: int) -> None:
        record = {
            "session_id": self.session_id,
            "player_id": self.player_id,
            "module": "kernel_watcher",
            "timestamp_ms": int((time.monotonic() - self.started) * 1000),
            "evidence": evidence,
            "reasons": reasons,
            "raw_score": score,
        }
        line = json.dumps(record, ensure_ascii=False, separators=(",", ":"))
        with self.path.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
        print(line, flush=True)


class RawJsonlWriter:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def emit(self, record: dict[str, Any]) -> None:
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n")


def contains_pattern(value: str, patterns: Iterable[str]) -> str | None:
    lower = value.lower()
    return next((pattern for pattern in patterns if pattern in lower), None)


def scan_loaded_drivers(config: dict[str, Any], writer: JsonlWriter,
                        raw_writer: RawJsonlWriter,
                        seen_matches: set[tuple[str, str]]) -> None:
    scores = config["scores"]
    for driver in enumerate_drivers():
        matched_name = contains_pattern(driver["name"], config["driver_name_patterns"])
        digest = None
        matched_hash = False
        path = Path(driver["path"]) if driver["path"] else None
        if config["driver_sha256"] and path:
            digest = sha256_file(path)
            matched_hash = digest is not None and digest.lower() in config["driver_sha256"]
        raw_writer.emit({
            "type": "driver_snapshot",
            "collected_unix_ms": int(time.time() * 1000),
            "driver_name": driver["name"],
            "driver_path": driver["path"],
            "driver_base": driver["base"],
            "sha256": digest,
        })
        reasons = []
        score = 0
        if matched_name:
            reasons.append("Blacklisted Driver Name Pattern")
            score += int(scores.get("driver_name_match", 3))
        if matched_hash:
            reasons.append("Blacklisted Driver SHA-256")
            score += int(scores.get("driver_hash_match", 5))
        if reasons:
            fingerprint = (driver["path"].lower(), digest or matched_name or "")
            if fingerprint in seen_matches:
                continue
            seen_matches.add(fingerprint)
            writer.emit({
                "event": "loaded_driver_match",
                "driver_name": driver["name"],
                "driver_path": driver["path"],
                "matched_pattern": matched_name,
                "sha256": digest,
            }, reasons, score)


def process_driver_events(device: KernelWatcherDevice, config: dict[str, Any],
                          writer: JsonlWriter, raw_writer: RawJsonlWriter) -> None:
    dropped, events = device.read_events()
    if dropped:
        writer.emit({"event": "queue_overflow", "dropped": dropped},
                    ["Kernel Event Queue Overflow"],
                    int(config["scores"].get("queue_overflow", 1)))
    for event in events:
        raw_writer.emit({"type": "process_event", **event})
        if not event["created"]:
            continue
        matched = contains_pattern(Path(event["image_path"]).name,
                                   config["process_name_patterns"])
        if matched:
            writer.emit({
                "event": "process_created_match",
                "pid": event["pid"],
                "parent_pid": event["parent_pid"],
                "image_path": event["image_path"],
                "matched_pattern": matched,
                "kernel_timestamp_100ns": event["timestamp_100ns"],
            }, ["Blacklisted Process Name Pattern"],
               int(config["scores"].get("process_name_match", 2)))


def run(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    writer = JsonlWriter(args.output, args.session_id, args.player_id)
    raw_writer = RawJsonlWriter(args.raw_output)
    seen_driver_matches: set[tuple[str, str]] = set()
    next_scan = 0.0
    with KernelWatcherDevice() as device:
        while True:
            process_driver_events(device, config, writer, raw_writer)
            now = time.monotonic()
            if now >= next_scan:
                scan_loaded_drivers(config, writer, raw_writer, seen_driver_matches)
                next_scan = now + args.driver_scan_interval
            if args.once:
                break
            time.sleep(args.poll_interval)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="KernelWatcher collector")
    parser.add_argument("--session-id", required=True)
    parser.add_argument("--player-id", required=True)
    parser.add_argument("--config", type=Path,
                        default=Path(__file__).with_name("blacklist.json"))
    parser.add_argument("--output", type=Path, default=Path("common_events.jsonl"))
    parser.add_argument("--raw-output", type=Path,
                        default=Path("kernel_raw_events.jsonl"))
    parser.add_argument("--poll-interval", type=float, default=0.5)
    parser.add_argument("--driver-scan-interval", type=float, default=30.0)
    parser.add_argument("--once", action="store_true")
    return parser.parse_args()


if __name__ == "__main__":
    try:
        run(parse_args())
    except KeyboardInterrupt:
        pass
    except Exception as exc:
        print(f"KernelWatcher collector error: {exc}", file=sys.stderr)
        raise SystemExit(1)
