# Live case 09

[PASS] 09.live_cross_view_discrepancy: Real fixture was present in AuxKlib and unmodified PSAPI; process-local filtered PSAPI omitted only its base for 3 cycles, production mismatch event persisted, then unmodified view and service cleanup were verified. Does not prove general hidden-driver detection.

Cleanup confirmed: True

Scope: A real signed fixture is loaded, then only this process's PSAPI response is filtered; both-view kernel hiding is not tested
