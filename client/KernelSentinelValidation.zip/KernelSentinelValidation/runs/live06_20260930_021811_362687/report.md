# Live case 06

[PASS] 06.live_entry_mutation: Actual NtQuerySystemInformation +7 byte 33->31 detected in 3 reads (mask=2); exact original bytes and finding clearance confirmed in 3 restored reads.

Restoration confirmed: True

Scope: Actual second entry probe, equivalent XOR encoding at +6; not all four probes and not live code-hash case 07
