# KernelSentinel validation

Mode: observe

| Case | Result | Detail |
|---|---|---|
| 00.runner | ERROR | FileNotFoundError: [WinError 2] 지정된 파일을 찾을 수 없습니다. |
