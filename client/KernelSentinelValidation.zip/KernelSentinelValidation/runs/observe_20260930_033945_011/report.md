# KernelSentinel fresh validation

Mode: observe

| Case | Result | Measurement |
|---|---|---|
| 00.bridge_preflight | ERROR | Host debugger bridge unavailable: ConnectionRefusedError: [WinError 10061] 대상 컴퓨터에서 연결을 거부했으므로 연결하지 못했습니다 |
