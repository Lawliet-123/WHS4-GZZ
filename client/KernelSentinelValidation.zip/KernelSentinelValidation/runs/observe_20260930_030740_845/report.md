# KernelSentinel validation

Mode: observe

| Case | Result | Detail |
|---|---|---|
| 01.reject_wrong_creation | PASS | Win32 error=87; policy identity must remain unchanged |
| 01.register_valid | PASS | pid=5052, generation=5, lease=1 |
| 02.process_create | PASS | Match exact target PID and creation time |
| 03.process.open.1000 | PASS | pre/post operation 1; actual access=0x1000 |
| 03.process.open.1010 | PASS | pre/post operation 2; actual access=0x1010 |
| 03.process.open.1028 | PASS | pre/post operation 4; actual access=0x1028 |
| 03.process.open.1002 | PASS | pre/post operation 5; actual access=0x1002 |
| 03.process.open.1040 | PASS | pre/post operation 6; actual access=0x1040 |
| 03.process.open.1801 | PASS | pre/post operation 7; actual access=0x1801 |
| 03.process.open.187b | PASS | pre/post operation 8; actual access=0x187b |
| 03.process.duplicate.1000 | PASS | pre/post operation 9; actual access=0x1000 |
| 03.process.duplicate.1010 | PASS | pre/post operation 10; actual access=0x1010 |
| 03.process.duplicate.1028 | PASS | pre/post operation 11; actual access=0x1028 |
| 03.process.duplicate.1002 | PASS | pre/post operation 12; actual access=0x1002 |
| 03.process.duplicate.1040 | PASS | pre/post operation 13; actual access=0x1040 |
| 03.process.duplicate.1801 | PASS | pre/post operation 14; actual access=0x1801 |
| 03.process.duplicate.187b | PASS | pre/post operation 15; actual access=0x187b |
| 03.thread.open.0800 | PASS | pre/post operation 16; actual access=0x800 |
| 03.thread.open.0808 | PASS | pre/post operation 17; actual access=0x808 |
| 03.thread.open.0810 | PASS | pre/post operation 18; actual access=0x810 |
| 03.thread.open.0802 | PASS | pre/post operation 19; actual access=0x1802; API request=0x802, callback original=0x1802 |
| 03.thread.open.0801 | PASS | pre/post operation 20; actual access=0x801 |
| 03.thread.open.081b | PASS | pre/post operation 21; actual access=0x181b; API request=0x81b, callback original=0x181b |
| 03.thread.duplicate.0800 | PASS | pre/post operation 22; actual access=0x800 |
| 03.thread.duplicate.0808 | PASS | pre/post operation 23; actual access=0x808 |
| 03.thread.duplicate.0810 | PASS | pre/post operation 24; actual access=0x810 |
| 03.thread.duplicate.0802 | PASS | pre/post operation 25; actual access=0x1802; API request=0x802, callback original=0x1802 |
| 03.thread.duplicate.0801 | PASS | pre/post operation 26; actual access=0x801 |
| 03.thread.duplicate.081b | PASS | pre/post operation 27; actual access=0x181b; API request=0x81b, callback original=0x181b |
| 04.memory_read | PASS | success=True, error=0, bytes=32; own target buffer |
| 04.memory_write | PASS | success=True, error=0, bytes=32; own target buffer |
| 04.preexisting_handle_read | PASS | Pre-registration read handle remains usable; this is a documented limitation |
| 02.thread_create | PASS | Exact test thread 7000 |
| 02.thread_exit | PASS | Exact test thread 7000 |
| 05.dll_load | PASS | Newly loaded fixture path, base, nonzero image size and export marker |
| 12.file_hash | PASS | Actual FileWorker hash and configured rule |
| 12.signature_not_cheat | PASS | Signature alone produces no cheat finding |
| 12.signature_collection | PASS | {'Status': 2, 'StatusMessage': 'C:\\Users\\wwwh\\Desktop\\KernelSentinelValidation\\bin\\KsValidationFixture.dll 파일이 디지털 서명되지 않았습니다. 현재 시스템에서 이 스크립트를 실행할 수 없습니다. 스크립트 실행 및 실행 정책 설정에 대한 자세한 내용은 about_Execution_Policies(https://go.microsoft.com/fwlink/?LinkID=135170)를 참조하십시오.'} |
| 05.driver_load | PASS | Fresh fixture load: matching events=1, base=0xfffff80055370000, size=40960, path=C:\Users\wwwh\Desktop\KernelSentinelValidation\bin\driver\KsValidationProbe.sys |
| 10.fixture_system_thread | PASS | Known fixture system thread tid=6440; start must be inside its loaded module |
| 05.probe_cleanup | PASS | Fixture stopped; delete exit=0 |
| 06.entry_read | PASS | valid=0xf, changed=0x0, failed=0x0; read coverage only |
| 08.dispatch_baseline | PASS | Unchanged own pointers inside module ranges |
| 09.cross_view | PASS | Three real bracketed snapshots; no persistent discrepancy |
| 10.thread_snapshot | PASS | OS build=19045, status=0x0; supported target is 19045 x64 |
| 11.callback_health | PASS | {"type": "callback_health", "outcome": "observed", "consecutive_misses": 0, "actor_pid": 3328, "target_pid": 5052, "generation": 5, "probe_access": 4096, "pre_count": 1, "post_count": 1, "scope": "collector_handle_callback_path_not_entire_callback_table"} |
| 07.live_code_comparison | PASS | comparisons=1, new_baselines=0, failed_scans=1, changes=0; bounded scan, no mutation |
| 02.target_exit | PASS | Protected-target exit event, exact PID and creation time |
| 01.exit_clears_policy | PASS | Policy cleared after target exit |
| 00.collection_loss | PASS | Dropped during run: 0 |
| 06.live_entry_mutation | PASS | Historical separate VM PASS (live06_20260930_021811_362687); Actual NtQuerySystemInformation +7 byte 33->31 detected in 3 reads (mask=2); exact original bytes and finding clearance confirmed in 3 restored reads. SHA-256 report=2decec1abc6dc766d03c70d6cec7cfd0129be452c3d1191959416ee193808975 |
| 07.live_code_mutation | PASS | Historical separate VM PASS (live07_20260930_022607_254744); Actual NT executable code hash changed after one-byte equivalent XOR encoding (flags=3 and production finding); original 32-byte entry and baseline hash restored (flags=1). SHA-256 report=e3e1b2d8e469df1f7c2a7174b7a2ec263a784bff83d088bc055ad00184f1e104 |
| 08.live_dispatch_mutation | PASS | Historical separate VM PASS (live08_20260929_210825_089994); Actual CREATE pointer changed; mask=1 and finding observed in 3 samples; exact original pointers, mask=0 and finding cleared in 3 restored samples. SHA-256 report=bc98eeebd4b3fb81170180a47e0bc1e6f96659730522f880f54e678dbbf0dbc4 |
| 09.live_cross_view_discrepancy | PASS | Historical separate VM PASS (live09_20260930_025153_142242); Real fixture was present in AuxKlib and unmodified PSAPI; process-local filtered PSAPI omitted only its base for 3 cycles, production mismatch event persisted, then unmodified view and service cleanup were verified. Does not prove general hidden-driver detection. SHA-256 report=9a0bdc12f059f3bf12a2229fd2aaf12e59ce4caff65214aa56dfb2b51d4072dc |
| 10.live_outside_thread | PASS | Historical separate VM PASS (live10_20260930_025625_793608); Real system thread started outside every loaded module range; exact identity persisted 3 scans, production finding appeared, fixture service stopped/deleted and module absent afterward. SHA-256 report=4cbd48abaaad3f66b579a1bbc098ae773452f9456cb45f228f06df3577742a70 |
| 09.live_hidden_driver | NOT_RUN | Kernel-level driver hiding was not performed; controlled PSAPI omission is a narrower check |
