# Live case 07

[PASS] 07.live_code_mutation: Actual NT executable code hash changed after one-byte equivalent XOR encoding (flags=3 and production finding); original 32-byte entry and baseline hash restored (flags=1).

Restoration confirmed: True

Scope: Actual NT executable-section hash change after first baseline; one reviewed equivalent encoding, not all kernel modules
