# KernelSentinel validation

Mode: observe

| Case | Result | Detail |
|---|---|---|
| 01.reject_wrong_creation | PASS | Win32 error=87; policy identity must remain unchanged |
| 01.register_valid | PASS | pid=10736, generation=1, lease=1 |
| 02.process_create | PASS | Match exact target PID and creation time |
| 03.process.open.1000 | PASS | pre/post operation 1; actual access=0x1000 |
| 03.process.open.1010 | PASS | pre/post operation 2; actual access=0x1010 |
| 03.process.open.1028 | PASS | pre/post operation 4; actual access=0x1028 |
| 03.process.open.1002 | PASS | pre/post operation 5; actual access=0x1002 |
| 03.process.open.1040 | PASS | pre/post operation 6; actual access=0x1040 |
| 03.process.open.1801 | PASS | pre/post operation 7; actual access=0x1801 |
| 03.process.open.187b | PASS | pre/post operation 8; actual access=0x187b |
| 03.process.duplicate.1000 | PASS | pre/post operation 9; actual access=0x1000 |
| 03.process.duplicate.1010 | PASS | pre/post operation 10; actual access=0x1010 |
| 03.process.duplicate.1028 | PASS | pre/post operation 11; actual access=0x1028 |
| 03.process.duplicate.1002 | PASS | pre/post operation 12; actual access=0x1002 |
| 03.process.duplicate.1040 | PASS | pre/post operation 13; actual access=0x1040 |
| 03.process.duplicate.1801 | PASS | pre/post operation 14; actual access=0x1801 |
| 03.process.duplicate.187b | PASS | pre/post operation 15; actual access=0x187b |
| 03.thread.open.0800 | PASS | pre/post operation 16; actual access=0x800 |
| 03.thread.open.0808 | PASS | pre/post operation 17; actual access=0x808 |
| 03.thread.open.0810 | PASS | pre/post operation 18; actual access=0x810 |
| 03.thread.open.0802 | PASS | pre/post operation 19; actual access=0x1802; API request=0x802, callback original=0x1802 |
| 03.thread.open.0801 | PASS | pre/post operation 20; actual access=0x801 |
| 03.thread.open.081b | PASS | pre/post operation 21; actual access=0x181b; API request=0x81b, callback original=0x181b |
| 03.thread.duplicate.0800 | PASS | pre/post operation 22; actual access=0x800 |
| 03.thread.duplicate.0808 | PASS | pre/post operation 23; actual access=0x808 |
| 03.thread.duplicate.0810 | PASS | pre/post operation 24; actual access=0x810 |
| 03.thread.duplicate.0802 | PASS | pre/post operation 25; actual access=0x1802; API request=0x802, callback original=0x1802 |
| 03.thread.duplicate.0801 | PASS | pre/post operation 26; actual access=0x801 |
| 03.thread.duplicate.081b | PASS | pre/post operation 27; actual access=0x181b; API request=0x81b, callback original=0x181b |
| 04.memory_read | PASS | success=True, error=0, bytes=32; own target buffer |
| 04.memory_write | PASS | success=True, error=0, bytes=32; own target buffer |
| 04.preexisting_handle_read | PASS | Pre-registration read handle remains usable; this is a documented limitation |
| 02.thread_create | PASS | Exact test thread 10852 |
| 02.thread_exit | PASS | Exact test thread 10852 |
| 05.dll_load | PASS | Newly loaded fixture path, base, nonzero image size and export marker |
| 12.file_hash | PASS | Actual FileWorker hash and configured rule |
| 12.signature_not_cheat | PASS | Signature alone produces no cheat finding |
| 12.signature_collection | PASS | {'Status': 2, 'StatusMessage': 'C:\\Users\\wwwh\\Desktop\\KernelSentinelValidation\\bin\\KsValidationFixture.dll 파일이 디지털 서명되지 않았습니다. 현재 시스템에서 이 스크립트를 실행할 수 없습니다. 스크립트 실행 및 실행 정책 설정에 대한 자세한 내용은 about_Execution_Policies(https://go.microsoft.com/fwlink/?LinkID=135170)를 참조하십시오.'} |
| 05.driver_load | PASS | Fresh fixture load: matching events=1, base=0xfffff80193ba0000, size=40960, path=C:\Users\wwwh\Desktop\KernelSentinelValidation\bin\driver\KsValidationProbe.sys |
| 10.fixture_system_thread | PASS | Known fixture system thread tid=11184; start must be inside its loaded module |
| 05.probe_cleanup | PASS | Fixture stopped; delete exit=0 |
| 06.entry_read | PASS | valid=0xf, changed=0x0, failed=0x0; read coverage only |
| 08.dispatch_baseline | PASS | Unchanged own pointers inside module ranges |
| 09.cross_view | PASS | Three real bracketed snapshots; no persistent discrepancy |
| 10.thread_snapshot | PASS | OS build=19045, status=0x0; supported target is 19045 x64 |
| 11.callback_health | PASS | {"type": "callback_health", "outcome": "observed", "consecutive_misses": 0, "actor_pid": 10636, "target_pid": 10736, "generation": 1, "probe_access": 4096, "pre_count": 1, "post_count": 1, "scope": "collector_handle_callback_path_not_entire_callback_table"} |
| 07.live_code_comparison | PASS | comparisons=1, new_baselines=179, failed_scans=1, changes=0; bounded scan, no mutation |
| 02.target_exit | PASS | Protected-target exit event, exact PID and creation time |
| 01.exit_clears_policy | PASS | Policy cleared after target exit |
| 00.collection_loss | PASS | Dropped during run: 0 |
| 06.live_entry_mutation | NOT_RUN | Kernel entry change is tested in the native isolated fixture |
| 07.live_code_mutation | NOT_RUN | Code mutation/hash algorithm is tested in the native isolated fixture |
| 08.live_dispatch_mutation | NOT_RUN | Actual integrity.h is tested using a fixture driver object |
| 09.live_hidden_driver | NOT_RUN | CrossView input discrepancies tested offline; real hiding is not asserted |
| 10.live_outside_thread | NOT_RUN | Outside-module boundary and persistence tested offline |
