# Live case 06

[ERROR] 06.live_entry_mutation: FileNotFoundError: [WinError 2] 지정된 파일을 찾을 수 없습니다.

Restoration confirmed: False

Scope: Actual second entry probe, equivalent XOR encoding at +6; not all four probes and not live code-hash case 07
