# Live case 10

[PASS] 10.live_outside_thread: Real system thread started outside every loaded module range; exact identity persisted 3 scans, production finding appeared, fixture service stopped/deleted and module absent afterward.

Cleanup confirmed: True

Scope: One owned system thread whose real start address is an executable pool trampoline outside loaded module ranges
