# KernelSentinel live case 08

[PASS] 08.live_dispatch_mutation: Actual CREATE pointer changed; mask=1 and finding observed in 3 samples; exact original pointers, mask=0 and finding cleared in 3 restored samples.

Restoration confirmed: True

Scope: Actual installed KernelSentinel CREATE dispatch pointer; does not cover outside-module provenance or cases 06/07/09/10
