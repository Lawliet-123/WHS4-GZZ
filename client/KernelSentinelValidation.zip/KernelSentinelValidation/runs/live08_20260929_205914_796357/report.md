# KernelSentinel live case 08

[FAIL] 08.live_dispatch_mutation: ValueError: Actual pointer values/baselines do not match this phase

Restoration confirmed: False

Scope: Actual installed KernelSentinel CREATE dispatch pointer; does not cover outside-module provenance or cases 06/07/09/10
