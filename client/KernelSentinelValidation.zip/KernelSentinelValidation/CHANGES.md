# 변경 및 발견 사항

## 원본과 비교

기준: 다운로드 폴더의 `KernelSentinel_v0.2.1_source.zip`.

- 원본 ZIP을 수정하지 않았습니다.
- 패키지의 `KernelSentinel/agent/files.py`, `KernelSentinel/driver/thread_scan.h`만 수정했습니다.
- 나머지 드라이버·프로토콜·정책·원본 테스트 소스는 동일합니다. 파일별 해시는 `source-manifest.json`에 기록합니다.
- 새 코드 전체는 패키지 루트와 `validation/` 아래에 있습니다.

## 서명 조회 호환성 수정

PowerShell 7 환경에서 원본 FileWorker의 자식 Windows PowerShell 5.1이 잘못된 모듈 경로를 상속해 `Microsoft.PowerShell.Security` 자동 로드에 실패했습니다. 결과는 `unavailable_command_failed`였습니다.

서명 조회 자식 프로세스에만 `PSModulePath`를 Windows PowerShell 기본 Modules 경로로 지정합니다. JSON 경로 입력 방식은 유지합니다. 출력은 UTF-8 JSON을 Base64 ASCII로 전달해 콘솔 없는 실행의 코드 페이지 영향을 줄입니다. 부모 환경은 변경하지 않습니다. 회귀 테스트는 경로의 한글/공백과 지역화된 응답, 부모 환경 유지까지 확인합니다.

## WDK 컴파일 오류 수정

WDK 10.0.28000.0에서 `thread_scan.h`의 `THREAD_QUERY_INFORMATION` 이름을 찾지 못해 C2065가 발생했습니다. 헤더에 정의가 없을 때만 `0x0040UL`로 보충했습니다. 이는 [문서화된 스레드 접근 권한](https://learn.microsoft.com/en-us/windows/win32/procthread/thread-security-and-access-rights)이며 권한 확대나 검사 알고리즘 변경이 아닙니다.

## 검증 환경 문제

- 설치된 GCC는 `mingw32`여서 기존 시스템 스레드 C 테스트의 8바이트 포인터 조건에 실패했습니다. 원본 C 파일 네 개를 수정 없이 MSVC x64로 빌드·실행하니 통과했습니다. `offline.py`는 GCC를 호출하는 원본 Python 래퍼 3개를 이 네 x64 실행 파일 검사로 대체하고 이를 결과에 명시합니다.
- 환경에 Path/PATH 중복 키가 전달되면 MSBuild가 시작하지 못했습니다. 새 빌드 런처는 자식 프로세스 환경 키의 대소문자를 통일합니다.
- 현재 WDK의 INF 검증 DLL을 찾지 못해 전체 KernelSentinel 패키지 빌드가 실패했습니다. 컴파일·링크 전용 실행은 성공했으며, INF/서명/설치 검증은 별도 미완료로 남깁니다.

## 계층의 구분

`native_sensor_test.c`는 실제 `integrity.h`와 `code_scan.h`를 include하여 실행합니다. OS 함수는 API 대역이며 해시는 실제 BCrypt SHA-256입니다. 통제된 버퍼의 변경/복구가 실제 코드에서 처리되는지는 확인하지만 라이브 커널 메모리 취득, 동시성, IRQL, PatchGuard와의 상호작용은 검증하지 않습니다.
