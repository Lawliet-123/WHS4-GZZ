# KernelSentinel validation

Mode: smoke

| Case | Result | Detail |
|---|---|---|
| 01.registration | NOT_RUN | Smoke mode does not open KernelSentinel |
| 03.process.open.1000 | PASS | Stimulus only; no anticheat verdict |
| 03.process.open.1010 | PASS | Stimulus only; no anticheat verdict |
| 03.process.open.1028 | PASS | Stimulus only; no anticheat verdict |
| 03.process.open.1002 | PASS | Stimulus only; no anticheat verdict |
| 03.process.open.1040 | PASS | Stimulus only; no anticheat verdict |
| 03.process.open.1801 | PASS | Stimulus only; no anticheat verdict |
| 03.process.open.187b | PASS | Stimulus only; no anticheat verdict |
| 03.process.duplicate.1000 | PASS | Stimulus only; no anticheat verdict |
| 03.process.duplicate.1010 | PASS | Stimulus only; no anticheat verdict |
| 03.process.duplicate.1028 | PASS | Stimulus only; no anticheat verdict |
| 03.process.duplicate.1002 | PASS | Stimulus only; no anticheat verdict |
| 03.process.duplicate.1040 | PASS | Stimulus only; no anticheat verdict |
| 03.process.duplicate.1801 | PASS | Stimulus only; no anticheat verdict |
| 03.process.duplicate.187b | PASS | Stimulus only; no anticheat verdict |
| 03.thread.open.0800 | PASS | Stimulus only; no anticheat verdict |
| 03.thread.open.0808 | PASS | Stimulus only; no anticheat verdict |
| 03.thread.open.0810 | PASS | Stimulus only; no anticheat verdict |
| 03.thread.open.0802 | PASS | Stimulus only; no anticheat verdict |
| 03.thread.open.0801 | PASS | Stimulus only; no anticheat verdict |
| 03.thread.open.081b | PASS | Stimulus only; no anticheat verdict |
| 03.thread.duplicate.0800 | PASS | Stimulus only; no anticheat verdict |
| 03.thread.duplicate.0808 | PASS | Stimulus only; no anticheat verdict |
| 03.thread.duplicate.0810 | PASS | Stimulus only; no anticheat verdict |
| 03.thread.duplicate.0802 | PASS | Stimulus only; no anticheat verdict |
| 03.thread.duplicate.0801 | PASS | Stimulus only; no anticheat verdict |
| 03.thread.duplicate.081b | PASS | Stimulus only; no anticheat verdict |
| 04.memory_read | PASS | success=True, error=0, bytes=32; own target buffer |
| 04.memory_write | PASS | success=True, error=0, bytes=32; own target buffer |
| 04.preexisting_handle_read | PASS | Pre-registration read handle remains usable; this is a documented limitation |
| 02.thread_stimulus | PASS | Own target created and joined a thread |
| 05.dll_stimulus | PASS | Loaded own fixture DLL |
| 12.file_hash | PASS | Actual FileWorker hash and configured rule |
| 12.signature_not_cheat | PASS | Signature alone produces no cheat finding |
| 12.signature_collection | INCONCLUSIVE | unavailable_command_failed |
| 05.driver_load | NOT_RUN | A newly loaded signed test driver is required; see coverage.md |
| 06.live_entry_mutation | NOT_RUN | Kernel entry change is tested in the native isolated fixture |
| 07.live_code_mutation | NOT_RUN | Code mutation/hash algorithm is tested in the native isolated fixture |
| 08.live_dispatch_mutation | NOT_RUN | Actual integrity.h is tested using a fixture driver object |
| 09.live_hidden_driver | NOT_RUN | CrossView input discrepancies tested offline; real hiding is not asserted |
| 10.live_outside_thread | NOT_RUN | Outside-module boundary and persistence tested offline |
