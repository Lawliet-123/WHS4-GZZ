# 실행 결과 — 2026-09-27

검증 환경: Windows 10 19045 x64, 64비트 Python, MSVC x64, Windows SDK/WDK 10.0.28000.0.

| 검사 | 결과 | 증거 |
|---|---|---|
| 원본 Python 테스트 + 신규 판정/서명 회귀 | **54개 통과**, 실패·오류·건너뜀 0 | `results/release-offline/python-tests.txt` |
| 원본 C 테스트 4개 + 신규 센서 테스트 실행 파일 | **5개 통과** | `results/release-offline/report.json` |
| 신규 센서 테스트 내부 검사 | **42개 조건 통과** | 실제 integrity.h/code_scan.h + OS API 대역 + BCrypt |
| 전용 프로세스 자극 및 파일 정보 수집 | **34개 PASS**, 7개 NOT_RUN | `results/release-smoke/report.md` |
| KernelSentinel.sys | x64 컴파일·링크 및 PE 산출물 확인 | `results/build-compile-only.txt`, `results/binaries.json` |
| KsValidationProbe.sys | x64 컴파일·링크 및 PE 산출물 확인 | `results/binaries.json` |
| 전체 INF·카탈로그·서명 패키징 | **미완료** | 현재 WDK의 INF 검증 구성 요소 누락; 컴파일 전용으로 확인 |
| 실제 observe/enforce 커널 실행 | **미실행** | 현재 환경에 KernelSentinel 서비스가 설치되어 있지 않음 |
| 실제 커널 함수 패치·은닉·모듈 밖 스레드 | **미실행** | 오프라인 검사 함수 테스트와 구분 |

54개 Python 검사와 42개 내부 조건은 서로 다른 단위이며 합산해 "96개 기능 통과"라고 해석하지 않습니다. 34개 smoke PASS도 안티치트의 탐지/차단 성공 건수가 아닙니다.

실제 실행 중 PowerShell 서명 조회 실패를 재현하고 수정했습니다. 마지막 실행에서는 FileWorker가 DLL의 SHA-256과 서명 상태 `2(NotSigned)`를 수집했고, 서명만으로 치트 판정을 내리지 않는 것을 확인했습니다. 원본 WDK 컴파일에서 확인한 스레드 접근 권한 이름 누락도 수정했습니다.

동봉 SYS는 **미서명**입니다. 해당 파일을 로드하지 않았으며 인증서 설치·부팅 옵션 변경·OS 함수 패치를 수행하지 않았습니다. VM에서 테스트 서명을 갖춘 뒤 README의 observe/enforce 절차를 실행해야 실제 센서와 권한 제한 결과가 채워집니다.

원본 `KernelSentinel/SHA256SUMS.json`, `KernelSentinel/TEST_RESULTS.txt`는 원본 배포 당시 자료입니다. 이번 패키지의 소스 변경 및 새 결과는 루트 `source-manifest.json`, `source-changes.patch`, `RESULTS.md`를 기준으로 보세요.
