# Run.ps1 새 실측 통합

이 패키지는 이전 `Run.ps1`과 `validation\live.py`, `KernelSentinel\agent\files.py`를 갱신하고 06~10번 실행기와 `validation\fresh.py`, `validation\debug_bridge.py`를 추가합니다. 적용 전 덮어쓸 세 파일을 백업하세요. VM에서 이전에 성공한 05번용 `bin\driver\KsValidationProbe.sys`와 10번용 `KsOutsideThreadProbe.sys`는 그대로 사용합니다.

먼저 호스트용 패키지의 `README-host.md`를 따라 보조 프로그램을 시작하고 `bridge.json`을 VM의 이 검증 폴더에 복사하세요. VM 관리자 PowerShell에서 다음을 실행합니다.

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
Set-Location C:\Users\wwwh\Desktop\KernelSentinelValidation
.\Run.ps1 -Mode observe -Signatures -FreshValidation
```

이 모드는 호스트 연결을 먼저 확인합니다. 실패하면 검증 대상에 변경을 가하기 전에 중단합니다. 연결되면 기존 observe 검사, 06 진입부 변조·복구, 07 실행 코드 해시 변조·복구, 08 CREATE 포인터 변조·복구, 09 실제 드라이버의 한쪽 목록 누락 검사, 10 실제 모듈 밖 스레드 검사를 **새로** 순서대로 수행합니다. 개별 `runs\observe_...\live06`~`live10` 폴더와 통합 `report.json`에 이번 실행에서 얻은 결과만 들어갑니다. 실패한 단계 뒤의 변조 시험은 진행하지 않습니다.

`12.signature_collection`은 미서명 시험 DLL을 `NotSigned`로 정확히 분류해야 PASS입니다. 새 `12.signature_valid_control`은 Windows가 서명한 `kernel32.dll`의 유효한 서명과 인증서 지문을 읽어야 PASS입니다. 기존 출력의 `Status=2`는 [PowerShell의 NotSigned 상태](https://learn.microsoft.com/en-us/dotnet/api/system.management.automation.signaturestatus)를 뜻합니다. 실행 정책 오류가 아니었으며 긴 `StatusMessage`는 이제 성공 판정 메시지로 사용하지 않습니다.

`09.live_cross_view_discrepancy`는 새로 검사하지만 `09.live_hidden_driver`는 계속 `NOT_RUN`입니다. 현재 KernelSentinel은 AuxKlib와 PSAPI 목록의 차이를 찾습니다. 같은 드라이버가 두 목록에서 동시에 빠지면 차이가 없어서 현재 판정기로는 탐지할 수 없습니다. 이 기능을 검증하려면 독립적인 드라이버 로드 기록과 이를 대조하는 센서를 먼저 추가해야 합니다.

첫 자동 디버깅 실행은 VM에서 아직 확인되지 않았습니다. 오류가 나면 통합 `Reports:` 경로와 호스트 보조 프로그램 출력을 보내 주세요. 복구 확인 없는 오류 뒤에는 다시 실행하거나 KernelSentinel을 내리기 전에 변조 상태를 확인하세요.
