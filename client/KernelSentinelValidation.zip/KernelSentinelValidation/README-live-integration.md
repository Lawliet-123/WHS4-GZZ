# 별도 실측 결과를 Run.ps1 보고서에 통합

이 ZIP은 `Run.ps1`, `validation\live.py`, 새 `validation\live_evidence.py`만 교체·추가하는 덮어쓰기 패키지입니다. 기존 KernelSentinel 드라이버나 06~10번 개별 시험 실행기를 변경하지 않습니다.

1. VM의 `C:\Users\wwwh\Desktop\KernelSentinelValidation`에서 기존 `Run.ps1`과 `validation\live.py`를 다른 폴더에 복사해 백업합니다.
2. ZIP의 폴더 구조대로 같은 위치에 압축을 풀어 두 파일을 덮어쓰고 `validation\live_evidence.py`를 추가합니다.
3. KernelSentinel 드라이버를 실행 상태로 두고 다른 `watch`/검증 세션을 종료한 뒤 관리자 PowerShell에서 실행합니다.

```powershell
Set-Location C:\Users\wwwh\Desktop\KernelSentinelValidation
.\Run.ps1 -Mode observe -Signatures -LiveEvidenceRoot .\runs
```

`-LiveEvidenceRoot`를 명시했을 때만 `runs\live06_*`부터 `runs\live10_*`까지 각 사례의 **가장 최근** 보고서를 읽습니다. 각 보고서의 `PASS`, 복구/정리 확인, 필요한 실측 단계 기록을 검사하고 현재 보고서에 `historical_live` 계층으로 출처와 보고서 SHA-256을 기록합니다. 이 옵션은 커널 메모리를 바꾸거나 시험 드라이버를 추가로 로드하지 않습니다. 옵션을 생략하면 개별 시험은 `NOT_RUN`입니다.

09번은 `09.live_cross_view_discrepancy`로 가져옵니다. `09.live_hidden_driver`는 커널 수준 은닉을 실행하지 않았으므로 계속 `NOT_RUN`입니다. 따라서 기본 Run.ps1의 종료 코드 2와 `Partial coverage` 문구는 예상됩니다. 이는 다른 항목의 PASS를 취소한다는 뜻이 아닙니다. 현재 실행에 실패 항목이 있으면 종료 코드 1입니다.

정확한 전체 보고서가 필요하면 `Reports:`에 표시된 폴더의 `report.json`, `report.md`, `truth.jsonl`을 확인하세요. 개별 실측 보고서 폴더를 삭제하거나 옮기면 가져오지 못합니다. 최신 폴더가 FAIL/미완료라면 이전 PASS를 임의로 가져오지 않고 `INCONCLUSIVE`로 표시합니다.
