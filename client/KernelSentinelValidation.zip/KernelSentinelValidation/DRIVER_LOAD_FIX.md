# 05.driver_load 실제 로드 검증 수정

기존 observe/enforce는 `-ProbeSys` 옵션이 없으면 05.driver_load를 항상 건너뛰었습니다. 이번 수정은 기존 Run.ps1 실행 경로에서 이 조건을 없애고 **실제 드라이버 로드를 기본 실행**합니다. 새 별도 실험 러너나 모의 로드 검증으로 대체하지 않습니다.

## 적용

ZIP 내용을 기존 `C:\Users\wwwh\Desktop\KernelSentinelValidation` 폴더에 풀어 병합합니다. Run.ps1, validation/live.py, validation/probe_service.py가 교체되고 driver_load.py 등이 추가됩니다. 해당 세 파일은 적용 전 백업하면 되돌릴 수 있습니다.

기존 KernelSentinel.sys, agent 소스, 핸들 매칭 수정 파일, 기존 서명된 `bin/driver/KsValidationProbe.sys`는 ZIP에 포함하지 않아 덮어쓰지 않습니다. 06~10의 원래 미실행 범위도 변경하지 않습니다.

기본 SYS 선택 순서는 다음과 같습니다.

1. 기존 `bin\driver\KsValidationProbe.sys`가 있으면 사용합니다.
2. 없으면 이번 ZIP의 `driver-load-fixture\KsValidationProbe.sys`를 사용합니다.

포함한 SYS는 기존의 **정상 로드 및 대기 스레드만 만드는 작은 테스트 드라이버**입니다. 커널 lab 변조 실험은 들어 있지 않습니다. 이 파일은 x64 미서명 바이너리이므로 VM에서 신뢰하는 테스트 인증서로 서명해야 합니다. 기존 SYS를 선택하더라도 그 파일의 서명이 VM에서 허용돼야 합니다.

## 실행

KernelSentinel 서비스가 실행 중인 테스트 VM에서 기존 watch/검증기를 종료한 뒤 관리자 PowerShell로 실행합니다.

```powershell
Set-Location 'C:\Users\wwwh\Desktop\KernelSentinelValidation'
.\Run.ps1 -Mode observe -Signatures
```

이번 수정부터 이 명령만으로 05가 실제 실행됩니다. SYS를 직접 지정하려면 기존 옵션도 그대로 쓸 수 있습니다.

```powershell
.\Run.ps1 -Mode observe -Signatures -ProbeSys '.\driver-load-fixture\KsValidationProbe.sys'
```

## PASS 기준

검증기가 새로 만든 KsValidationProbe 서비스를 시작하고, 설치된 KernelSentinel에서 수집한 새 `kernel_image` 이벤트를 확인합니다. 로드 시작 이후 시각, 지정한 SYS의 전체 경로, 실제 모듈 목록의 주소와 크기가 모두 일치하는 이벤트가 정확히 하나여야 PASS입니다. 기존에 로드돼 있던 드라이버나 같은 파일명만 가진 이벤트는 인정하지 않습니다. 이벤트 유실/모듈 조회 실패는 INCONCLUSIVE입니다.

서비스를 시작하지 못하면 `05.driver_load ERROR`에 실제 원인을 기록합니다. 테스트 소유 서비스는 성공/실패 모두 정리하며, 기존 동명 서비스는 수정하지 않습니다. 다른 검증 항목은 계속 실행합니다.

정상적으로 이 항목까지 검증되면 다음과 같은 결과가 나옵니다. 이는 기대 출력 예시이며 새 VM 실행 결과는 아닙니다.

```text
[PASS] 05.driver_load: Fresh fixture load: matching events=1, ...
[PASS] 05.probe_cleanup: Fixture stopped; delete exit=0
```

## 서명 문제일 때

`Load fixture failed: 577`은 테스트 SYS 서명을 Windows가 거부했다는 뜻입니다. `-Signatures` 옵션은 파일 서명 **정보 수집** 옵션이며 SYS를 서명하거나 로드를 허용하지 않습니다.

기존 VM에서 신뢰하는 코드서명 인증서와 개인 키, SignTool이 있는 컴퓨터에서 다음을 실행합니다. 기본적으로 러너가 선택하는 SYS를 서명합니다.

```powershell
.\Sign-DriverLoad.ps1 -Thumbprint '실제_인증서_40자리_지문'
```

로컬 컴퓨터의 개인 인증서 저장소를 쓰면 `-StoreLocation LocalMachine`을 추가합니다. SYS 경로를 직접 지정할 때는 서명과 실행 명령의 `-ProbeSys`를 같은 값으로 지정하세요. 다른 컴퓨터에서 서명했다면 서명한 SYS를 VM으로 복사해야 합니다. 이 스크립트는 인증서 신뢰나 부팅 설정을 바꾸지 않습니다.

`5`는 관리자 권한, `2`는 SYS 경로, `1275`는 Windows 드라이버 차단 정책 및 Code Integrity 로그를 확인해야 합니다. 실행 로그에도 해당 안내와 선택한 SYS 경로가 기록됩니다.

의도적으로 드라이버 로드를 제외하려는 경우에만 `-SkipDriverLoad`를 지정합니다. smoke/offline은 커널 드라이버를 로드하지 않습니다.

## 확인 범위

Python 회귀 테스트 76개와 기존 C 실행 파일 5개 통과. 실제 이벤트의 경로/시각/주소/크기 불일치, 이벤트 누락/중복, 유실, 이미 로드된 드라이버, 서명 오류 안내, 실패 후 정리, 기본 실행 옵션을 검사했습니다. PowerShell 구문 검사도 통과했습니다. 이 작업 환경에서 드라이버를 로드하지 않았으며 **새 VM의 05 PASS는 아직 확인하지 않았습니다.**

검증 보고서는 driver-load-evidence/report.json, 파일 해시는 driver-load-evidence/manifest.json을 참고하세요.
