# 스레드 접근 권한 매칭 수정

## 확인한 원인

제공한 observe 로그의 실패 4개는 콜백 누락이 아니었습니다. operation_id 19, 21, 25, 27의 pre/post가 모두 있으며, 시각·generation·actor/target/source/recipient PID·대상 TID가 실행 기록과 일치합니다. post의 실제 권한도 독립 NtQueryObject 결과와 같습니다.

| 요청 종류 | API 요청 | 콜백 OriginalDesiredAccess 및 실제 권한 |
|---|---|---|
| 스레드 열기/복제 | 0x0802 | 0x1802 |
| 스레드 열기/복제 | 0x081B | 0x181B |

원래 검증기는 API 요청과 콜백 입력이 항상 동일하다고 가정했습니다. 이 실행에서는 suspend/resume 비트 0x2가 포함된 요청에 0x1000이 추가돼 엄격한 일치 조건에서 제외됐습니다. 0x1000은 [phnt의 THREAD_RESUME 정의](https://github.com/winsiderss/phnt/blob/master/ntpsapi.h)와도 일치합니다. 정규화의 정확한 내부 시점/경로는 이 로그만으로 증명하지 않습니다.

수정은 스레드 요청에 0x2가 있을 때 원래 값 또는 0x1000만 추가된 값 두 경우를 인정합니다. 프로세스 권한, 다른 추가/누락 비트, PID/TID, 시각, generation, operation_id, 성공 상태, 독립 실제 권한 비교, enforce의 제거 마스크 조건은 완화하지 않습니다.

## 적용

기존 검증기를 종료한 상태에서 이 ZIP을 **기존 KernelSentinelValidation 폴더에 압축 해제**하여 `validation/checks.py`를 교체하세요. `validation/tests/test_thread_access_normalization.py`는 신규 회귀 테스트입니다.

KernelSentinel 드라이버와 agent/protocol 파일은 포함하지 않습니다. 드라이버 재설치·재서명은 필요 없습니다. 기존 `validation/checks.py`를 백업하면 되돌릴 수 있습니다.

관리자 PowerShell에서 기존 폴더로 이동한 뒤:

```powershell
.\Run.ps1 -Mode observe -Signatures
# 위 실행이 끝난 뒤
.\Run.ps1 -Mode enforce -Signatures
```

## 재검증 결과

- 기존 로그의 핸들 26건을 새 판정기로 재분석: **26건 PASS**. 기존 4건 FAIL의 원인을 원본 판정기로 먼저 재현했습니다.
- Python 회귀 테스트 **64개 통과**, x64 C 실행 파일 **5개 통과**. `hotfix-tests.json` 참조.
- 이것은 기존 observe 증거의 재분석입니다. 수정 후 VM 새 실행 및 enforce 검증은 아직 수행하지 않았습니다.
- 실제 SYS/에이전트의 제한 정책은 변경하지 않습니다. 0x13 제거 성공이 THREAD_RESUME 0x1000까지 제거하거나 모든 스레드 제어를 차단한다는 뜻은 아닙니다.

## 별도로 남는 검사 범위

코드 스캔은 179개 기준 생성, 1개 기존 기준 비교, 1개 실패였습니다. 실패는 `\SystemRoot\system32\hal.dll`, status `0xC0000225`, bytes_hashed `0`입니다. 이 실행으로 hal.dll이 검사됐다고 볼 수 없으며, 원인 확정에는 해당 VM의 모듈 이미지/검사 경로 확인이 필요합니다. 한 번의 비교 PASS를 전체 커널 모듈 검사 완료로 해석하지 마세요.

새 드라이버 로드와 실제 커널 변조·은닉·모듈 밖 스레드 실험 6개는 원래 보고서대로 NOT_RUN입니다. 서명 정보의 Status 2는 정상 테스트 DLL이 미서명이라는 뜻이며 검증 스크립트 실행 실패가 아닙니다.

원본 사용자 로그는 변경하지 않았습니다. `observe-log-review.json`은 별도 재분석 결과입니다.
