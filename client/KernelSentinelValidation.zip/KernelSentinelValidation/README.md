# KernelSentinel 기능별 검증 도구

`KernelSentinel_v0.2.1_source.zip`을 기준으로 만든 검증 패키지입니다. 사용자 표의 12개 기능을 [검증 범위표](coverage.md)에 대응시켰습니다. 전용 프로세스·DLL·드라이버로 실제 이벤트를 만들고, 별도로 원본 검사 함수에 통제된 데이터를 넣어 변경·복구·실패 조건을 검사합니다.

**현재 확인한 결과는 [실행 결과](RESULTS.md)를 보세요. 실제 KernelSentinel 드라이버를 로드한 observe/enforce 검증은 아직 실행하지 않았습니다.**

## 빠른 시작

Windows x64, Python 3.10 이상 **64비트**가 필요합니다. 외부 Python 패키지는 없습니다. 이미 빌드한 x64 테스트 실행 파일과 DLL을 포함합니다. 아래 명령은 압축을 푼 패키지 루트에서 실행합니다. `python`이 없으면 실제 설치한 Python 경로를 `-Python`에 지정합니다.

```powershell
# 커널을 로드하지 않는 검사 함수·분석기 테스트
.\Run.ps1 -Mode offline

# 전용 프로세스의 핸들/메모리/스레드/DLL과 파일 서명 조회 확인
.\Run.ps1 -Mode smoke -Signatures
```

각 실행은 새로운 `runs` 하위 폴더에 결과를 만듭니다. 기존 결과 폴더는 덮어쓰지 않습니다.

## 실제 드라이버 검증

시스템 스레드 센서의 대상은 **Windows 10 19045 x64**입니다. 스냅샷을 확보한 테스트 VM에서 KernelSentinel을 정상 서명·로드한 뒤 관리자 PowerShell로 실행합니다. 기존 `agent.main watch`는 종료해야 합니다. 드라이버 장치는 수집기 하나만 열 수 있고, 이 검증기가 직접 정책 설정과 수집을 담당합니다.

```powershell
.\Run.ps1 -Mode observe -Signatures
.\Run.ps1 -Mode enforce -Signatures
```

실제 게임 PID를 입력하지 않습니다. 검증기가 만든 전용 대상만 등록합니다. `enforce`에서는 요청 권한과 필터링 후 권한, `NtQueryObject`로 독립 조회한 실제 권한을 대조합니다. 메모리 접근은 대상이 공개한 테스트 버퍼 32바이트에 한정합니다. 읽기는 성공, 새 쓰기 핸들로 쓰기는 접근 거부가 기대값입니다. 스레드 생성·종료는 대상 프로세스가 협조적으로 수행합니다. `CREATE_THREAD`, `TERMINATE`, `SET_CONTEXT` 등은 핸들 권한만 요청하며 원격 코드 실행이나 스레드 종료를 시도하지 않습니다.

`--code-scans` / `-CodeScans` 기본값은 520회입니다. 이 범위 안에서 기존 기준과 비교한 모듈 하나가 나오는지 확인합니다. 모든 모듈의 코드 검증을 완료했다는 뜻은 아닙니다. 기준 생성만 나오거나 조회가 실패하면 `INCONCLUSIVE`입니다.

## 새 드라이버 로드와 정상 시스템 스레드 확인

`KsValidationProbe.sys`는 자신의 시스템 스레드를 하나 만들고 종료 이벤트를 기다립니다. 조회 IOCTL 하나로 그 스레드 ID만 반환합니다. 해당 드라이버를 테스트 서명한 뒤 다음과 같이 지정할 수 있습니다.

```powershell
.\Run.ps1 -Mode observe -ProbeSys .\bin\driver\KsValidationProbe.sys
```

이 옵션을 지정하면 검증기가 `KsValidationProbe` 서비스를 만들고 로드해 `kernel_image`를 대조합니다. 알려진 스레드의 시작 주소가 해당 드라이버 이미지 범위 안인지 확인한 뒤 서비스를 중지·삭제합니다. 이미 같은 이름의 서비스가 있으면 덮어쓰지 않고 중단합니다. 종료 오류는 결과에 기록하며 임의로 강제 언로드하지 않습니다.

**동봉된 `.sys`는 컴파일·링크 확인용 미서명 파일입니다.** VM에서 테스트 서명과 신뢰 조건을 갖춰야 로드할 수 있습니다. 스크립트가 테스트 서명 부팅, Secure Boot, 메모리 무결성 설정을 변경하지 않습니다. 기본 실행은 드라이버 서비스를 설치하거나 로드하지 않습니다.

## 빌드

일반 테스트와 DLL에는 Visual Studio C++ x64 도구와 Windows SDK가 필요합니다.

```powershell
.\Build.ps1
```

WDK가 정상 구성된 환경에서 테스트 드라이버와 KernelSentinel을 테스트 서명 빌드하려면:

```powershell
.\Build.ps1 -Driver -KernelSentinel
```

코드의 컴파일·링크만 확인하려면:

```powershell
.\Build.ps1 -Driver -KernelSentinel -Unsigned -CompileOnly
```

`-CompileOnly`는 INF 검증·카탈로그 생성·서명을 수행하지 않습니다. 정상 설치 패키지 검증을 통과했다는 의미가 아닙니다. 이 환경에서는 WDK INF 검증 DLL 누락으로 전체 패키징을 확인하지 못했습니다.

산출물은 `bin/driver/KsValidationProbe.sys`, `KernelSentinel/build/x64/Debug/KernelSentinel.sys`입니다. KernelSentinel의 설치·시작은 포함된 원본 `KernelSentinel/scripts/Install.ps1` 사용법에 따라 VM에서 별도로 수행하세요.

## 결과 해석

| 결과 | 의미 |
|---|---|
| PASS | 해당 계층의 구체적인 기대값을 확인함 |
| FAIL | 수집한 증거가 기대값과 다르거나 필요한 이벤트가 없음 |
| INCONCLUSIVE | 큐 손실, 조회 실패, 지원하지 않는 OS, 비교 기준 부족 등으로 판정 불가 |
| NOT_RUN | 해당 실험을 실행하지 않음 |
| ERROR | 준비·실행·정리 오류 |

종료 코드: `0`은 실행 집합 통과, `1`은 실패·오류, `2`는 미실행·판정 불가가 남은 부분 검증입니다. `smoke`가 정상이어도 커널 항목이 남아 `2`가 반환됩니다. 라이브 검사도 실제 커널 변조 항목은 별도로 미실행 표시하므로 일반적으로 `2`가 정상적인 부분 결과입니다.

`report.json`/`report.md`는 항목별 결과, `truth.jsonl`은 독립 실행 기록, `raw_events.jsonl`은 드라이버·센서 증거입니다. 오프라인 결과에는 Python 테스트 로그와 각 C 테스트의 종료 코드가 들어갑니다. 합성 입력이나 API 대역을 사용한 테스트를 실제 커널에서의 탐지 성공으로 합산하지 않습니다.

## 포함된 소스 수정

다운로드 원본 ZIP은 그대로 보존했습니다. 패키지 안 KernelSentinel 사본에는 다음 두 수정만 적용했습니다. 자세한 diff는 `source-changes.patch`와 [변경 기록](CHANGES.md)에 있습니다.

1. `agent/files.py`: PowerShell 7에서 전달된 모듈 경로 때문에 Windows PowerShell 서명 조회가 실패하는 문제와 지역화 문자열 전송 문제 수정.
2. `driver/thread_scan.h`: 현재 WDK의 커널 헤더에서 빠진 `THREAD_QUERY_INFORMATION` 이름을 문서화된 값으로 보충. 권한이나 검사 로직은 동일.

## 검증에 사용한 API 근거

- [OB create/duplicate 및 pre/post 콜백](https://learn.microsoft.com/en-us/windows-hardware/drivers/ddi/wdm/ns-wdm-_ob_operation_registration)
- [NtQueryObject의 실제 GrantedAccess 조회](https://learn.microsoft.com/en-us/windows/win32/api/winternl/nf-winternl-ntqueryobject)
- [문서화된 스레드 접근 권한](https://learn.microsoft.com/en-us/windows/win32/procthread/thread-security-and-access-rights)

커널 진입부 변경은 운영체제 함수에 패치를 쓰는 대신 동일한 `integrity.h`가 읽는 격리 버퍼를 변경해 검사합니다. 커널 코드 해시는 동일한 `code_scan.h`에 유효한 PE 이미지 버퍼를 전달하고 실제 BCrypt SHA-256을 사용합니다. 이런 검사로 실제 커널 메모리 취득 경로나 모든 후킹의 탐지를 보장하지는 않습니다.
