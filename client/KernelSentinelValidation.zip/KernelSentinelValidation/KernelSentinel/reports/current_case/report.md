# KernelSentinel 증거 분리 분석

**드라이버 로드와 핸들 접근은 실제 메모리 읽기 탐지로 판정하지 않는다.**

| 사실 | 결과 |
|---|---|
| 선택한 드라이버 로드 | 1건 |
| 선택한 클라이언트의 게임 핸들 결과 | 2건 |
| 외부 CSV의 읽기 성공 보고 | 102건, 서로 다른 좌표 31개 |
| KernelSentinel의 직접 읽기 관측 | 센서 미구현·관측 불가 |
| 시간순 연결에 의한 치트 확정/추가 점수 | 없음 / 0 |

## 핸들 호출 원인

| UTC | PID | 원래 요청 | 실제 부여 | 호출 근거 |
|---|---:|---|---|---|
| 2026-09-26T17:13:38.2326677Z | 6056 | 0x1000 | 0x1000 | unidentified |
| 2026-09-26T17:13:38.2328562Z | 6056 | 0x1FFFFF | 0x1FFFFF | unidentified |

`api_interval_candidate`는 API 실행 구간 후보이며 native 호출 스택 증거가 아니다.
현재 미확인 호출의 원인을 Toolhelp 내부 호출 등으로 확정하지 않는다.

## 시간순 증거

| UTC | 출처/원시 행 | 사실 | 핵심 값 |
|---|---|---|---|
| 2026-09-26T17:06:21.1271997Z | raw:2462 | kernel_image | \Device\HarddiskVolume3\Users\wwwh\Desktop\ChameleonKernelProbe\build\driver\ChameleonKernelProbe.sys |
| 2026-09-26T17:06:21.2110000Z | raw:2472 | driver_snapshot | \??\C:\Users\wwwh\Desktop\ChameleonKernelProbe\build\driver\ChameleonKernelProbe.sys |
| 2026-09-26T17:06:21.3130000Z | raw:2476 | file_evidence | \Device\HarddiskVolume3\Users\wwwh\Desktop\ChameleonKernelProbe\build\driver\ChameleonKernelProbe.sys; SHA-256=590474f21d889f295335e758db47d4b27e9c4d07c0484c7d6fe9e4f4b4b8a2cd |
| 2026-09-26T17:06:21.3130000Z | raw:2477 | file_evidence | \??\C:\Users\wwwh\Desktop\ChameleonKernelProbe\build\driver\ChameleonKernelProbe.sys; SHA-256=590474f21d889f295335e758db47d4b27e9c4d07c0484c7d6fe9e4f4b4b8a2cd |
| 2026-09-26T17:06:38.7692174Z | raw:2699 | process_create | PID 9052; \??\C:\Users\wwwh\Desktop\ChameleonKernelProbe\build\client\ChameleonCoord.exe |
| 2026-09-26T17:06:38.7860955Z | raw:2700 | process_exit | 9052 |
| 2026-09-26T17:06:54.9327423Z | raw:2917 | process_create | PID 2500; \??\C:\Users\wwwh\Desktop\ChameleonKernelProbe\build\client\ChameleonCoord.exe |
| 2026-09-26T17:06:54.9375392Z | raw:2918 | process_exit | 2500 |
| 2026-09-26T17:09:45.3372683Z | raw:5308 | process_create | PID 1128; \??\C:\Users\wwwh\Desktop\ChameleonKernelProbe\build\client\ChameleonCoord.exe |
| 2026-09-26T17:09:45.3474457Z | raw:5309 | process_exit | 1128 |
| 2026-09-26T17:13:12.7161956Z | raw:8017 | process_create | PID 6728; \??\C:\Users\wwwh\Desktop\ChameleonKernelProbe\build\client\ChameleonCoord.exe |
| 2026-09-26T17:13:12.7250045Z | raw:8018 | process_exit | 6728 |
| 2026-09-26T17:13:38.2272109Z | raw:8417 | process_create | PID 6056; \??\C:\Users\wwwh\Desktop\ChameleonKernelProbe\build\client\ChameleonCoord.exe |
| 2026-09-26T17:13:38.2326628Z | raw:8418 | handle_pre | PID 6056 → 2376, requested=0x1000 |
| 2026-09-26T17:13:38.2326677Z | raw:8419 | handle_post | PID 6056 → 2376, access=0x1000 |
| 2026-09-26T17:13:38.2328365Z | raw:8420 | handle_pre | PID 6056 → 2376, requested=0x1fffff |
| 2026-09-26T17:13:38.2328562Z | raw:8421 | handle_post | PID 6056 → 2376, access=0x1fffff |
| 2026-09-26T17:14:35.0832264Z | raw:9459 | process_exit | 6056 |

외부 좌표 보고 구간: 2026-09-26T17:13:38.2650000Z ~ 2026-09-26T17:14:34.7480000Z

전체 행별 연결·연결 이유·오탐 가능성은 `evidence.json`의 `links`를 확인한다.
PID는 관측된 생성/종료 구간으로 구분하며, 새 로그는 생성 시각과 요청 TID를 추가로 사용한다.
로드와 프로세스 실행의 시간 근접은 정상 설치 프로그램·관리 도구에서도 발생할 수 있다.

## 관측 공백

일반 스레드의 IOCTL 처리 중 정상 로드된 드라이버가 게임 메모리를 읽는 동작은 직접 관측하지 않는다.
코드 변화가 없고 콜백이 정상이라는 사실도 그 읽기가 없었다는 증거가 아니다.
CSV는 시험 도구의 자체 보고이다. 실제 커널 읽기의 정답은 소스/실험 바이너리/독립 디버거 관찰과 함께 평가한다.

## 수집 품질

```json
{
  "gap_events": [],
  "kernel_ring_dropped_total_max": 0,
  "code_checks": {
    "0x00000000/flags=1": 1292,
    "0xC0000225/flags=0": 7,
    "0x00000000/flags=4": 1
  },
  "selected_driver_code_checks": {
    "0x00000000/flags=4": 1,
    "0x00000000/flags=1": 5
  }
}
```
