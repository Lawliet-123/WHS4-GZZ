# KernelSentinel: 기준 해시 재사용 수정 패치

## 로그에서 확인한 사실

제공된 vm_test_001 원시 로그를 분석했습니다.

- kernel_code_scan: 332회, 모듈 경로 180개.
- 성공 330회는 모두 flags=4(기준 생성), 비교 flags=1/3은 0회.
- 같은 주소·크기·경로로 성공적으로 두 번 검사된 모듈: 151개.
- 위 151개는 두 번의 current SHA-256이 모두 같았습니다.
- 실패 2회는 hal.dll의 0xC0000225입니다. 이 패치로 해당 검사를 정상 성공으로 바꾸거나 로그에서 숨기지 않습니다.
- 별도 export/자체 디스패치 진단 332회는 valid=15, changed=0, failed=0, dispatch=0이었습니다.

기준 재사용이 되지 않는 현상은 로그로 확인했습니다. 기존 구현은 경로 문자열의 NUL 종료 뒤 영역까지 256바이트 전체를 비교합니다. API가 문자열 뒤 영역에 동일한 값을 유지한다는 보장은 없으므로 같은 경로도 다른 키로 취급될 수 있습니다. JSON 로그는 NUL 뒤 원시 바이트를 보존하지 않아, 이 현상이 실제 원인인지는 기존 로그만으로 확정할 수 없습니다.

## 변경

- 경로 비교를 NUL 종료 문자열 기준으로 수정하고 ASCII 대소문자 차이를 허용합니다. 서로 다른 주소·크기·경로는 계속 구분합니다.
- 저장 경로는 NUL 뒤 영역을 0으로 채웁니다.
- 재조회 모듈 존재 확인도 같은 경로 비교를 사용합니다.
- 기준 캐시 로직을 code_cache.h로 분리해 실제 드라이버와 동일한 함수를 C 회귀 테스트에서 실행합니다.
- 빈 슬롯을 먼저 사용하고 꽉 찬 경우 별도 커서로 교체합니다.
- 해시가 달라져도 원래 기준을 자동 갱신하지 않습니다. 드라이버 로드 알림에 의한 기준 무효화는 유지합니다.
- 앞서 Windows 10 로드를 위해 안내한 ExAllocatePool2/ExFreePoolWithTag 수정도 KernelSentinel.c에 반영했습니다. 사용하지 않는 lookaside 초기화·삭제도 제거했습니다.
- IOCTL 구조, Python 파일, 빌드 프로젝트 설정은 변경하지 않습니다.

## 빌드 PC 적용

이 패치의 driver 폴더 안 파일 3개를 기존 프로젝트의 driver 폴더에 덮어쓰세요.

1. KernelSentinel.c
2. code_scan.h
3. code_cache.h (신규)

기존에 빌드 성공한 프로젝트 설정은 그대로 사용합니다. 새 헤더는 같은 폴더에 두면 #include로 포함되며 vcxproj에 수동 등록할 필요는 없습니다. Visual Studio에서 **솔루션 다시 빌드** 후 새 SYS를 VM으로 복사하세요.

## VM 적용

수집기 창에서 Ctrl+C로 종료한 뒤 관리자 PowerShell:

```powershell
sc.exe stop KernelSentinel
```

STOPPED 확인 후 새 SYS를 C:\Users\wwwh\Desktop\KernelSentinel\KernelSentinel.sys에 덮어씁니다. 프로젝트 폴더에서 설치 스크립트를 다시 실행해야 System32\drivers의 실제 로드 파일도 갱신됩니다.

```powershell
cd "C:\Users\wwwh\Desktop\KernelSentinel"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\scripts\Install.ps1" -SysPath ".\KernelSentinel.sys"
```

RUNNING 확인 후 실제 게임 PID로 실행합니다. 11192는 이전 세션 PID이며 게임을 재시작했다면 바꿔야 합니다.

```powershell
python -m agent.main watch --pid 11192 --mode observe --session-id vm_cachefix_001 --player-id player_local --out .\runs\vm_cachefix_001 --interval 2 --code-per-cycle 4
```

180개 기준 첫 순회는 최소 약 90초+처리 시간입니다. 두 번째 순회에서 비교 결과가 생겨야 합니다. 다른 PowerShell 창에서 아래 한 줄을 실행하세요.

```powershell
Get-Content "C:\Users\wwwh\Desktop\KernelSentinel\runs\vm_cachefix_001\raw_events.jsonl" | ConvertFrom-Json | Where-Object { $_.type -eq 'kernel_code_scan' -and $_.status -eq 0 -and ($_.flags -band 1) -ne 0 } | Select-Object -Last 10 path, flags, bytes_hashed | Format-Table -AutoSize
```

flags=1이면 기준과 같은 결과, flags=3이면 기준과 다른 결과입니다. flags=3만으로 악성이라고 판정하지 않습니다. 재검사 횟수가 충분한데도 모두 flags=4이면 최신 SYS와 새 raw_events.jsonl로 추가 확인해야 합니다.

## 검증 범위

Linux GCC에서 드라이버와 공유하는 C 캐시 함수를 컴파일·실행했습니다.

- 같은 경로에 서로 다른 NUL 뒤 바이트: 기존 memcmp 방식에서 불일치 재현, 새 문자열 비교에서 동일 판정.
- 첫 방문 flags=4 → 재방문 flags=1.
- 해시 변경 flags=3, 이후 검사에서도 원래 기준 보존.
- 로드 알림에 해당하는 무효화 후 flags=4.
- 180개 모듈 3회 순회(540회): 첫 순회 기준 생성, 다음 2회 비교 성공.
- 대소문자 차이, 서로 다른 경로, 미종료 문자열 처리.

테스트: 프로젝트 루트에서 `gcc -std=c11 -Wall -Wextra -Werror -I driver tests/cache_test.c -o cache_test` 후 실행.

수정된 드라이버의 Windows 빌드·VM 실행은 이 환경에서 수행하지 못했습니다. 따라서 이 패치는 확인된 코드 결함을 수정하고 회귀 테스트한 소스이며, 이번 VM 문제의 해결 완료 여부는 재빌드·로드 후 결과로 확인해야 합니다.
