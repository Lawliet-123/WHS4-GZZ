# 05.driver_load 오류 123 경로 수정

앞서 제공한 driver-load-fix를 적용한 폴더에 이 ZIP을 병합하세요. 핵심 교체 파일은 validation/probe_service.py 하나이며, 회귀 테스트 두 파일과 결과 보고서가 함께 포함돼 있습니다. SYS 파일과 서명은 변경하지 않습니다.

수신 로그에서 실제 로드 시도는 있었으나 sc.exe start가 123으로 실패했습니다. 123은 ERROR_INVALID_NAME(경로/이름 형식 오류)입니다. 기존 코드는 커널 서비스의 binPath에 따옴표 문자를 직접 포함했습니다. 서비스 생성 성공과 드라이버 로드 성공은 별개이므로 이 문제는 시작 단계에서 드러날 수 있습니다. 제공된 콘솔 로그에는 레지스트리 ImagePath가 없어 해당 VM에서의 최종 원인 확인은 아직 남아 있습니다.

수정은 절대 로컬 파일 경로를 따옴표 없는 NT 경로 `\??\C:\...\KsValidationProbe.sys`로 전달합니다. 공백이 있는 명령줄 인수의 전달 처리는 subprocess에 맡깁니다. 서비스 생성 직후 레지스트리 ImagePath를 읽어 기대값과 비교하고 truth.jsonl의 fixture_registered_path에 저장합니다. 경로가 잘못 저장됐다면 시작 전에 ERROR를 남기고 테스트가 만든 서비스를 정리합니다.

적용 후 VM 관리자 PowerShell에서 기존 명령을 다시 실행하세요.

```powershell
.\Run.ps1 -Mode observe -Signatures
```

직전 로그의 `05.probe_cleanup PASS`에 따르면 실패 후 임시 서비스는 삭제됐습니다. 별도 수동 삭제나 KernelSentinel 재설치는 필요하지 않습니다.

Python 82개와 기존 C 실행 파일 5개 통과. 공백/한글 경로, Windows 명령줄 인수 왕복, 잘못된 따옴표, 서비스 생성 인수, 등록 경로 검증을 포함했습니다. 드라이버를 이 작업 환경에서 로드하지 않았으며 VM의 실제 05 PASS는 아직 확인하지 않았습니다.

참고: [Microsoft 오류 코드 목록](https://learn.microsoft.com/en-us/windows/win32/debug/system-error-codes--0-499-).
